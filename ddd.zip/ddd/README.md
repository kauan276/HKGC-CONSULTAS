nd n KKKKKK zoas

aqui vai ta como usar a v1 dessas "puxadas" blz ent vamo

#1: pkg install pyhton
#2: pip install requests colorama
#3: cd /sdcard/ddd //Caso nos download 
#!!: cd /sdcard/Download/ddd
#4: python hkgc_consultas.py //Comando de inicialização 