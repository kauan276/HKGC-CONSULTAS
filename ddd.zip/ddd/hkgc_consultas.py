#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import requests
import re
import webbrowser
from colorama import Fore, Style, init

# Inicializa cores
init()

# Configurações
API_DDD = "https://brasilapi.com.br/api/ddd/v1/{ddd}"
API_CEP = "https://brasilapi.com.br/api/cep/v1/{cep}"
API_PLACA = "https://apicarros.com/v1/consulta/{placa}/json"  # API paga - necessita cadastro
URL_RECEITA = "https://servicos.receita.fazenda.gov.br/Servicos/CPF/ConsultaSituacao/ConsultaPublica.asp"

def exibir_banner():
    print(Fore.CYAN + r"""
    ██╗  ██╗██╗  ██╗ ██████╗  ██████╗
    ██║  ██║██║  ██║██╔════╝ ██╔════╝
    ███████║███████║██║  ███╗██║  ███╗
    ██╔══██║██╔══██║██║   ██║██║   ██║
    ██║  ██║██║  ██║╚██████╔╝╚██████╔╝
    ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝  ╚═════╝
    """ + Style.RESET_ALL)
    print(Fore.GREEN + "    By: HKGC CHANNEL | Ferramenta de Consultas" + Style.RESET_ALL)
    print("\n")

def exibir_menu():
    print(Fore.MAGENTA + "    [1]" + Style.RESET_ALL + " Consultar DDD")
    print(Fore.MAGENTA + "    [2]" + Style.RESET_ALL + " Consultar CEP")
    print(Fore.MAGENTA + "    [3]" + Style.RESET_ALL + " Consultar CPF (ético)")
    print(Fore.MAGENTA + "    [4]" + Style.RESET_ALL + " Consultar Placa (ético)")
    print(Fore.MAGENTA + "    [5]" + Style.RESET_ALL + " Validar Nome")
    print(Fore.MAGENTA + "    [6]" + Style.RESET_ALL + " Sair")
    return input(Fore.BLUE + "    >>> Escolha uma opção: " + Style.RESET_ALL)

def consultar_ddd():
    ddd = input(Fore.BLUE + "    Digite o DDD (ex: 11): " + Style.RESET_ALL)
    if not ddd.isdigit() or len(ddd) != 2:
        print(Fore.RED + "    DDD inválido! Deve ter 2 dígitos." + Style.RESET_ALL)
        return
    
    try:
        response = requests.get(API_DDD.format(ddd=ddd))
        dados = response.json()
        
        if "state" in dados:
            print(Fore.GREEN + f"\n    Estado: {dados['state']}")
            print(f"    Cidades: {', '.join(dados['cities'])}" + Style.RESET_ALL)
        else:
            print(Fore.RED + "    DDD não encontrado!" + Style.RESET_ALL)
    except Exception as e:
        print(Fore.RED + f"    Erro na consulta: {str(e)}" + Style.RESET_ALL)

def consultar_cep():
    cep = input(Fore.BLUE + "    Digite o CEP (ex: 01001000): " + Style.RESET_ALL)
    if not cep.isdigit() or len(cep) != 8:
        print(Fore.RED + "    CEP inválido! Deve ter 8 dígitos." + Style.RESET_ALL)
        return
    
    try:
        response = requests.get(API_CEP.format(cep=cep))
        dados = response.json()
        
        if "cep" in dados:
            print(Fore.GREEN + f"\n    CEP: {dados['cep']}")
            print(f"    Logradouro: {dados.get('street', 'N/A')}")
            print(f"    Bairro: {dados.get('neighborhood', 'N/A')}")
            print(f"    Cidade: {dados.get('city', 'N/A')}")
            print(f"    Estado: {dados.get('state', 'N/A')}")
            print(f"    DDD: {dados.get('ddd', 'N/A')}" + Style.RESET_ALL)
        else:
            print(Fore.RED + "    CEP não encontrado!" + Style.RESET_ALL)
    except Exception as e:
        print(Fore.RED + f"    Erro na consulta: {str(e)}" + Style.RESET_ALL)

def consultar_cpf():
    print(Fore.YELLOW + "\n    Abrindo consulta oficial da Receita Federal..." + Style.RESET_ALL)
    print(Fore.CYAN + "    Você será redirecionado para o site oficial.")
    print(Fore.CYAN + "    Complete o CAPTCHA manualmente para consultar.\n" + Style.RESET_ALL)
    webbrowser.open(URL_RECEITA)
    input(Fore.BLUE + "    Pressione ENTER para continuar..." + Style.RESET_ALL)

def consultar_placa():
    placa = input(Fore.BLUE + "    Digite a placa (ex: ABC1234): " + Style.RESET_ALL).upper()
    if not re.match(r'^[A-Z]{3}\d{4}$', placa) and not re.match(r'^[A-Z]{3}\d[A-Z]\d{2}$', placa):
        print(Fore.RED + "    Formato de placa inválido! Use o formato ABC1234 ou ABC1D23" + Style.RESET_ALL)
        return
    
    # Simulação - API real requer cadastro pago
    print(Fore.GREEN + f"""
    Placa: {placa}
    Modelo: Volkswagen Gol 1.6 (Simulação)
    Ano: 2020
    Cor: Prata
    Situação: Regular
    """ + Style.RESET_ALL)
    print(Fore.YELLOW + "    AVISO: Esta é uma simulação. Para dados reais, use APIs profissionais." + Style.RESET_ALL)

def validar_nome():
    nome = input(Fore.BLUE + "    Digite o nome completo: " + Style.RESET_ALL).strip()
    partes_nome = nome.split()
    
    if len(partes_nome) < 2:
        print(Fore.RED + "    Nome inválido! Digite nome e sobrenome." + Style.RESET_ALL)
    else:
        print(Fore.GREEN + f"""
    Nome: {nome}
    Nome válido: Sim
    Primeiro nome: {partes_nome[0]}
    Sobrenome: {' '.join(partes_nome[1:])}
    """ + Style.RESET_ALL)
        print(Fore.YELLOW + "    Observação: Esta validação verifica apenas a estrutura do nome." + Style.RESET_ALL)

def main():
    while True:
        exibir_banner()
        opcao = exibir_menu()
        
        if opcao == "1":
            consultar_ddd()
        elif opcao == "2":
            consultar_cep()
        elif opcao == "3":
            consultar_cpf()
        elif opcao == "4":
            consultar_placa()
        elif opcao == "5":
            validar_nome()
        elif opcao == "6":
            print(Fore.YELLOW + "\n    Saindo... HKGC na área! 🚀" + Style.RESET_ALL)
            break
        else:
            print(Fore.RED + "    Opção inválida!" + Style.RESET_ALL)
        
        input(Fore.BLUE + "\n    Pressione ENTER para continuar..." + Style.RESET_ALL)

if __name__ == "__main__":
    main()